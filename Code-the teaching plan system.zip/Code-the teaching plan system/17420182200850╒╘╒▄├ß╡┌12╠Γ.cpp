﻿// 17420182200850赵哲冕第12题.cpp : 此文件包含 "main" 函数。
/*	 Preparation of teaching plan
	 教学计划编制系统——design by 赵哲冕*/

#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<math.h>

#define TRUE 1
#define FALSE 0
#define OK 1
#define ERROR -1
#define OVERFLOW -1
#define MAX_NO 4				//最大编号值
#define MAX_VERTEX_NUM 100        //最大顶点数

int terms;//学期数
int gradelimits;//每学期学分限制
int* indegree;//入度数组

typedef char VertexType;
typedef int ElemType;
typedef int Status;


/*****———————————数据结构部分———————————*****/
/* ----------栈的链式存储---------- */
typedef struct Node
{
	ElemType data;//栈的元素
	struct Node* next;//链接指针
}Node, * PNode;
typedef struct LinkStack
{
	PNode top;//栈顶指针
}LinkStack, * PLinkStack;

/* ----------栈的操作---------- */
//建一个空栈
PLinkStack CreateEmptyStack(void)
{
	PLinkStack plstack;

	plstack = (PLinkStack)malloc(sizeof(struct LinkStack));
	if (plstack != NULL)
		plstack->top = NULL;
	else
		printf("Out of space!");
	return plstack;
}

//判断是否为空栈
Status IsEmptyStack(PLinkStack plstack)
{
	return(plstack->top == NULL);
}

//出栈操作
void PopStack(PLinkStack plstack)
{
	PNode p;

	if (IsEmptyStack(plstack))
	{
		printf("Stack Is Empty!\n");
	}
	else
	{
		p = plstack->top;
		plstack->top = plstack->top->next;
		free(p);
	}
}

//进栈操作
void PushStack(PLinkStack plstack, int x)
{
	PNode p;
	p = (PNode)malloc(sizeof(struct Node));

	if (p == NULL)
	{
		printf("Out Of Space!");
	}
	else
	{
		p->data = x;
		p->next = plstack->top;
		plstack->top = p;
	}
}

//取栈顶元素
Status GetTop(PLinkStack plstack)
{
	if (IsEmptyStack(plstack))
	{
		printf("Stack Is Empty!");
	}
	else
		return (plstack->top->data);
}

/*---------邻接表的构建---------*/
typedef struct EdgeNode* PEdgeNode;
typedef struct EdgeNode  //边表结点
{
	int adjvex;             //邻接点域，存储该顶点对应的下标
	char E_data[MAX_NO];	//边表的课程编号
	struct EdgeNode* next;  //指向下一个邻接点
}EdgeNode;

typedef struct VertexNode //顶点表结点
{
	char V_data[MAX_NO];     //存储顶点信息，即课程编号
	int grade;               //存储学分信息
	EdgeNode* firstedge;     //边表的头指针
}VertexNode, * AdjList;

typedef struct /*邻接表*/
{
	AdjList adjList;          //邻接表数组
	int numVertexes;          //图中当前顶点数
}graphAdjList, * GraphAdjList;

/*---------邻接表的操作---------*/
GraphAdjList CreateGraph_List()
{
	//创建一个空图
	GraphAdjList g = (GraphAdjList)malloc(sizeof(graphAdjList));

	if (g == NULL)
	{
		printf("OVERFLOW!");
	}
	else
	{
		g->adjList = (AdjList)malloc(sizeof(VertexNode) * MAX_VERTEX_NUM);
		if (g->adjList)
		{
			g->numVertexes = 0;
			return g;
		}
		else
			free(g);

	}

	return 0;
}

//求各顶点的入度
void FindIndegree(GraphAdjList g, int* indegree)
{
	int i;
	PEdgeNode p;

	for (i = 0; i < g->numVertexes; i++) indegree[i] = 0;//先初始化，全为零 
	for (i = 0; i < g->numVertexes; i++) {
		p = g->adjList[i].firstedge;
		while (p != NULL) {
			indegree[i]++;
			p = p->next;
		}
	}
}

//确定顶点在顶点表中的下标
Status Locate(GraphAdjList g, char* vertex)
{
	int i;

	for (i = 0; i < g->numVertexes; i++)
	{
		if (strcmp(g->adjList[i].V_data, vertex) == 0)
			break;
	}

	return i;
}

//在顶点表中增加结点
Status AddVex(GraphAdjList g, char* vertex, int grade)
{
	if (g->numVertexes < MAX_VERTEX_NUM)
	{
		strcpy_s(g->adjList[g->numVertexes].V_data, vertex);
		g->adjList[g->numVertexes].grade = grade;
		g->adjList[g->numVertexes].firstedge = NULL;
		g->numVertexes = g->numVertexes + 1;

		return OK;
	}
	else {
		printf("OVERFLOW!\n");

		return OVERFLOW;
	}
}

//在边表中增加结点
Status AddEdge(GraphAdjList g, char* vertex, char* adjv)//图，当前课程编号，插入课程编号
{

	int i;
	EdgeNode* q;
	PEdgeNode pe = (PEdgeNode)malloc(sizeof(struct EdgeNode));

	if (pe != NULL)//分配空间成功 
	{
		i = Locate(g, adjv);
		pe->adjvex = i;
		strcpy_s(pe->E_data, adjv);
		i = Locate(g, vertex);
		q = g->adjList[i].firstedge;
		g->adjList[i].firstedge = pe;
		pe->next = q;

		return OK;
	}
	else {//分配空间失败 
		printf("OVERFLOW!\n");

		return OVERFLOW;
	}
}

/* --判断是否为空图-- */
Status IsNullGraph_list(GraphAdjList g)
{
	return(g->numVertexes == 0);
}


/*****———————————核心算法部分———————————*****/
/*---------拓扑排序算法---------*/
Status ToplogicalSort(GraphAdjList G, int* TSArray)
{
	PEdgeNode p;
	EdgeNode* e;
	int i, j, k, nodeno = 0;        //拓扑序列数组中元素的个数 
	PLinkStack plstack = CreateEmptyStack();

	indegree = (int*)malloc(sizeof(int) * G->numVertexes);       //存储各节点的入度的数组 
	FindIndegree(G, indegree);					 //求各节点的入度 

	for (i = 0; i < G->numVertexes; i++)
	{
		if (indegree[i] == 0)
		{
			PushStack(plstack, i);				//先将所有入度为零的节点的下标压入栈中 
		}
	}

	while (!IsEmptyStack(plstack))
	{	//当栈不为空时 
		j = GetTop(plstack);					//取栈顶元素 
		PopStack(plstack);						//出栈 
		TSArray[nodeno++] = j;					// 将下标存入拓扑序列数组，个数自加 

		for (k = 0; k < G->numVertexes; k++)
		{   //查找下标为j的节点的后继 
			p = G->adjList[k].firstedge;		//顶点k的边表头指针
			while (p != NULL)
			{
				if (p->adjvex == j)
				{//j为入度为零元素的下标，当相等时，vex[k]就是该元素的后继 
					indegree[k] = indegree[k] - 1;//将该元素的入度减一 
					if (indegree[k] == 0)
					{      //减一后为零就压入栈中 
						PushStack(plstack, k);
					}

				}

				p = p->next;
			}
		}
	}
	free(indegree);     //释放空间 
	free(plstack);
	if (nodeno < G->numVertexes) {    //如果拓扑序列数组元素个数小于AOV网的顶点数，说明拓扑排序失败 
		printf("警告：该AOV网中含有回路！请检查输入的数据！\n");

		return ERROR;
	}
	system("cls");

	return OK;
}

/*---------课程安排的前驱后继图---------*/
void RelationshipMap(GraphAdjList g, int* TSArray)
{
	int i, j;
	PEdgeNode p;//定义边表结点指针

	printf("-------------------------------------------------------------------------------\n");
	printf("该课程安排的前驱后继关系图为：\n");
	for (i = 0; i < g->numVertexes; i++)//循环顶点表中的每一个顶点，即每门课程
	{
		int k = 0;

		for (j = 0; j < g->numVertexes; j++)//循环边表中的每一个顶点，即每门课程
		{
			p = g->adjList[j].firstedge;//顶点表中指向边表的头指针
			while (p != NULL)//如果有后继的课程的话则进入循环
			{
				if (strcmp(p->E_data, g->adjList[i].V_data) == 0)//若边表中的课程号与顶点表中的课程号相等
				{
					printf("%s", g->adjList[i].V_data);//打印顶点表中的课程号
					printf("---->%s", g->adjList[j].V_data);//打印边表中的第一个顶点
					break;
				}
				p = p->next;//指向边表中的下一个结点
			}
			if (p != NULL && strcmp(p->E_data, g->adjList[i].V_data) == 0)//若有后继结点且边表中的课程号与顶点表中的课程号相等
			{
				k = j;//将边表中后面的结点序号赋值给k
				break;
			}
		}
		for (j = k + 1; j < g->numVertexes; j++)//打印边表中后续的结点编号
		{
			p = g->adjList[j].firstedge;//顶点表中指向边表的头指针
			while (p != NULL)
			{
				if (strcmp(p->E_data, g->adjList[i].V_data) == 0)
				{
					printf(",%s", g->adjList[j].V_data);
				}
				p = p->next;
			}
		}
		printf("\n");
	}
	printf("该课程安排的排序方案为：\n");
	for (i = 0; i < g->numVertexes; i++)
	{
		printf("%s ", g->adjList[TSArray[i]].V_data);
	}
	printf("\n");
	printf("-------------------------------------------------------------------------------\n");
}

/*---------课程安排算法---------*/
void Strategy(GraphAdjList g, int* TSArray)
{
	int i, j, grade;

	printf("-------------------------------------------------------------------------------\n");
	for (i = 0, j = 0; i < terms; i++)//第1-8个学期开始循环
	{
		grade = 0;
		printf("第%d个学期的课程为： ", i + 1);
		while ((grade += g->adjList[TSArray[j]].grade) <= gradelimits)//当该学期修的学分小于限制学分时进行排课
		{
			printf("%s ", g->adjList[TSArray[j]].V_data);//打印课程编号
			j++;
			if (j > g->numVertexes - 1) break;//如果课程排完了则退出
		}
		if (j > g->numVertexes - 1) break;//如果课程排完了则退出
		printf("\n");
	}
	printf("\n-------------------------------------------------------------------------------\n");
}

/*---------课程关系手动输入---------*/
Status Input(GraphAdjList g)
{
	int i, j, n, grade, in;
	char str[100], str2[100];

	printf("请输入教学课程总数量：");
	scanf_s("%d", &n); getchar();
	for (i = 0; i < n; i++)
	{
		printf("请输入第%d门课程的编号：", i + 1);
		gets_s(str);
		printf("请输入%s课程的学分：", str);
		scanf_s("%d", &grade);
		printf("请输入%s课程的先修课程数量：", str);
		scanf_s("%d", &in); getchar();
		AddVex(g, str, grade);
		if (in)
		{
			for (j = 0; j < in; j++)
			{
				printf("请输入%s课程的第%d门先修课程的编号:", str, j + 1);
				gets_s(str2);
				AddEdge(g, str, str2);
			}

		}
		printf("-------------------------------------------------------------------------------\n");
	}

	return OK;
}

/*---------用户界面设计---------*/
Status UI(GraphAdjList g)
{

	printf("\t\t-------------------------------------------------\n");
	printf("\t\t|            欢迎使用教学计划编制系统           |\n");
	printf("\t\t|               design by 赵哲冕                |\n");
	printf("\t\t-------------------------------------------------\n");
	printf("\t\t                请按任意键继续...");
	
	getchar();
	system("cls");
	printf("\t\t-------------------------------------------------\n");
	printf("\t\t| 请按提示进行输入操作，如输入错误请重新启动程序|\n");
	printf("\t\t-------------------------------------------------\n");



	return 0;

}

/*---------主函数---------*/
int main()
{
	GraphAdjList g = CreateGraph_List();
	int* TSA;
	TSA = (int*)malloc(sizeof(int) * g->numVertexes);

	UI(g);//用户界面
	Input(g); //手动输入
	if (ToplogicalSort(g, TSA) != 1)
	{//拓扑排序 
		return -1;
	}
	printf("\t\t-------------------------------------------------\n");
	printf("\t\t|            教学计划编制系统正在运行           |\n");
	printf("\t\t-------------------------------------------------\n");
	RelationshipMap(g, TSA);//显示顶点间的前驱后继关系
	printf("\t\t                请按任意键继续...");
	getchar();
	system("cls");

	printf("\t\t-------------------------------------------------\n");
	printf("\t\t| 请按提示进行输入操作，如输入错误请重新启动程序|\n");
	printf("\t\t-------------------------------------------------\n");
	printf("\n请输入学期总数：");
	scanf_s("%d", &terms); getchar();
	printf("\n请输入每学期学分上限：");
	scanf_s("%d", &gradelimits); getchar();
	system("cls");
	printf("\t\t-------------------------------------------------\n");
	printf("\t\t|            教学计划编制系统正在运行           |\n");
	printf("\t\t-------------------------------------------------\n");
	Strategy(g, TSA);//使得课程尽可能地集中在前面的学期中

	printf("\n");
	printf("\t\t-------------------------------------------------\n");
	printf("\t\t|	    教学计划编制系统运行完毕！          |\n");
	printf("\t\t-------------------------------------------------\n");
	printf("\t\t                请按任意键退出。\n"); getchar();
}


